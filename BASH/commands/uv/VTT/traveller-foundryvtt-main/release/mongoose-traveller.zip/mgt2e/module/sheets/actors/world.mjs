import {MgT2ActorSheet} from "../actor-sheet.mjs";
import {MgT2Item} from "../../documents/item.mjs";
import {
    calculateFreightLots, clearFreight,
    createFreight,
    createSpeculativeGoods,
    distanceBetweenWorlds, tradeDisembarkPassengerHandler
} from "../../helpers/utils/trade-utils.mjs";
import {createFaction, createWorld, setTradeCodes, worldDropBrokerHandler} from "../../helpers/utils/world-utils.mjs";
import {MGT2} from "../../helpers/config.mjs";
import {getFromNamedTable, getRollTableFolder} from "../../helpers/utils/table-utils.mjs";
import {roll} from "../../helpers/dice-rolls.mjs";
import {Tools} from "../../helpers/chat/tools.mjs";

export class MgT2WorldActorSheet extends MgT2ActorSheet {
    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            classes: [ "mgt2", "sheet", "actor"],
            template: "systems/mgt2e/templates/actor/actor-world-sheet.html",
            width: 720,
            height: 600,
            tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "skills" }]
        });
    }

    async getDestination(worldActor, destinationWorlds, destId) {
        if (!destinationWorlds[destId]) {
            let world = await fromUuid(destId);
            destinationWorlds[destId] = {
                name: world.name,
                parsecs: distanceBetweenWorlds(worldActor, world),
                freight: [],
                passengers: [],
                mail: []
            }
        }
        return destinationWorlds[destId];
    }

    async _prepareItems(context) {
        context.cargo = [];
        context.factions = [];
        context.patrons = [];
        context.stars = [];
        context.planets = [];
        context.localGoods = [];
        // Faction and Patron text may include secrets, so we need to pre-process depending
        // on whether we hide the secret blocks or not from the description.
        context.patronText = {};
        context.factionText = {};

        let destinationWorlds = {};
        for (let i of context.items) {
            i.img = i.img || CONFIG.MGT2.DEFAULT_ITEM_ICON;
            i.cssStyle = "";

            // Append to gear.
            if (i.type === 'cargo') {
                // Add some meta data.
                let basePrice = i.system.cargo.price;
                if (i.system.cargo.speculative || i.system.cargo.purchasable) {
                    i.system.cargo.costDiff = i.system.cost - basePrice;
                    i.system.cargo.costSign = Math.sign(i.system.cargo.costDiff);
                    i.system.cargo.saleDiff = i.system.cargo.salePrice - basePrice;
                    i.system.cargo.saleSign = Math.sign(i.system.cargo.saleDiff);
                    context.cargo.push(i);
                } else if (i.system.cargo.freight) {
                    i.system.cargo.totalPrice = parseInt(i.system.cargo.price) * parseInt(i.system.quantity);
                    let dest = await this.getDestination(context.actor, destinationWorlds, i.system.cargo.destinationId);
                    dest.freight.push(i);
                } else {
                    context.localGoods.push(i);
                }
            } else if (i.type === "worlddata") {
                if (i.system?.world?.datatype === "faction") {
                    if (!i.system.world.hidden || context.actor.permission > 2) {
                        context.factions.push(i);
                        context.factionText[i._id] = await TextEditor.enrichHTML(
                            i.system.description, {
                                secrets: context.isEditable
                            }
                        );
                    }
                } else if (i.system?.world?.datatype === "patron") {
                    if (!i.system.world.hidden || context.actor.permission > 2) {
                        context.patrons.push(i);
                        context.patronText[i._id] = await TextEditor.enrichHTML(
                            i.system.description, {
                                secrets: context.isEditable
                            }
                        );
                    }
                } else if (i.system?.world?.datatype === "passenger") {
                    let dest = await this.getDestination(context.actor, destinationWorlds, i.system.world.destinationId);
                    dest.passengers.push(i);
                } else if (i.system?.world?.datatype === "planet") {
                    context.planets.push(i);
                } else if (i.system?.world?.datatype === "star") {
                    context.stars.push(i);
                }
            }
        }
        context.destinationWorlds = destinationWorlds;
    }

    _canDragStart() {
        // If you can see it, you can drag from it. This allows the
        // trade mechanism, but means we need to be careful about
        // everything else.
        return true
    }

    _canDragDrop() {
        // Allow freight, trade goods and passengers to be dropped on
        // a world.
        return true;
    }

    async getData() {
        const context = await super.getData();

        if (context.actor.permission > 2) {
            context.isEditable = true;
        } else {
            context.isEditable = false;
        }

        context.enrichedDescription = await TextEditor.enrichHTML(
            this.object.system.description,
            { secrets: ((context.actor.permission > 2)?true:false) }
        );

        await this._prepareItems(context);

        context.system = context.actor.system;
        context.world = context.system.world;

        let tradeCodes = context.world.uwp.codes;
        setTradeCodes(context.actor);
        if (tradeCodes !== context.world.uwp.codes) {
            await context.actor.update({"system.world.uwp.codes": context.world.uwp.codes});
        }

        context.PORT_SELECT = {};
        for (let p in CONFIG.MGT2.WORLD.starport) {
            context.PORT_SELECT[p] = `${p} - ${game.i18n.localize("MGT2.WorldSheet.Starport.Quality." + p)}`;
        }

        context.SIZE_SELECT = {};
        for (let d in CONFIG.MGT2.WORLD.size) {
            const h = game.settings.get("mgt2e", "hexInWorldMenus")?Tools.toHex(d):d;
            context.SIZE_SELECT[d] = `${h} - ${CONFIG.MGT2.WORLD.size[d].diameter}`;
        }

        context.ATMOSPHERE_SELECT = {};
        for (let d in CONFIG.MGT2.WORLD.atmosphere) {
            const h = game.settings.get("mgt2e", "hexInWorldMenus")?Tools.toHex(d):d;
            context.ATMOSPHERE_SELECT[d] = `${h} - ${game.i18n.localize("MGT2.WorldSheet.Atmosphere.Composition." + d)}`;
        }

        context.HYDROGRAPHICS_SELECT = {};
        for (let d in CONFIG.MGT2.WORLD.hydrographics) {
            const h = game.settings.get("mgt2e", "hexInWorldMenus")?Tools.toHex(d):d;
            context.HYDROGRAPHICS_SELECT[d] = `${ parseInt(d) * 10 }% - ${game.i18n.localize("MGT2.WorldSheet.Hydrographics.Description."+d)}`;
        }

        context.POPULATION_SELECT = {};
        for (let d in CONFIG.MGT2.WORLD.population) {
            const h = game.settings.get("mgt2e", "hexInWorldMenus")?Tools.toHex(d):d;
            let v = parseInt(CONFIG.MGT2.WORLD.population[d].range);
            v = v * Math.max(1, parseInt(context.world.extra.popDigit) || 1);
            context.POPULATION_SELECT[d] = `${h} - ${v.toLocaleString()}`;
        }
        context.POPULATION_DIGIT_SELECT = {};
        for (let d=1; d < 10; d++) {
            context.POPULATION_DIGIT_SELECT[d] = d;
        }

        context.GOVERNMENT_SELECT = {};
        for (let d in CONFIG.MGT2.WORLD.government) {
            const h = game.settings.get("mgt2e", "hexInWorldMenus")?Tools.toHex(d):d;
            context.GOVERNMENT_SELECT[d] = `${h} - ${game.i18n.localize("MGT2.WorldSheet.Government.Type." + d)}`;
        }

        context.LAW_SELECT = {};
        for (let d in CONFIG.MGT2.WORLD.lawLevel) {
            const h = game.settings.get("mgt2e", "hexInWorldMenus")?Tools.toHex(d):d;
            context.LAW_SELECT[d] = `${h} - ${game.i18n.localize("MGT2.WorldSheet.Law.Weapons." + d)}`;
        }

        context.TECH_SELECT = {};
        for (let d in CONFIG.MGT2.WORLD.techLevel) {
            const h = game.settings.get("mgt2e", "hexInWorldMenus")?Tools.toHex(d):d;
            context.TECH_SELECT[d] = `${h} - ${game.i18n.localize("MGT2.Item.Tech." + d)}`;
        }
        context.ZONE_SELECT = {
            "": "-",
            "Amber": game.i18n.localize("MGT2.Trade.Amber"),
            "Red": game.i18n.localize("MGT2.Trade.Red")
        };
        for (let d in CONFIG.MGT2.WORLD.techLevel) {
            const h = game.settings.get("mgt2e", "hexInWorldMenus")?Tools.toHex(d):d;
            context.TECH_SELECT[d] = `${h} - ${game.i18n.localize("MGT2.Item.Tech." + d)}`;
        }

        context.BROKER_SELECT = {}
        for (let i=0; i < 5; i++) {
            context.BROKER_SELECT[i] = i;
        }

        context.brokerActorImg = "systems/mgt2e/icons/misc/drop-target.svg";
        context.brokerActorName = "";
        context.streetwiseActorImg = "systems/mgt2e/icons/misc/drop-target.svg";
        context.streetwiseActorName = "";

        if (context.world.meta.brokerActorId) {
            let brokerActor = fromUuidSync(context.world.meta.brokerActorId);
            if (brokerActor && ["traveller", "npc"].includes(brokerActor.type)) {
                context.brokerActorImg = brokerActor.img;
                context.brokerActorName = brokerActor.name;
            }
        }
        if (context.world.meta.streetwiseActorId) {
            let streetwiseActor = fromUuidSync(context.world.meta.streetwiseActorId);
            if (streetwiseActor && ["traveller", "npc"].includes(streetwiseActor.type)) {
                context.streetwiseActorImg = streetwiseActor.img;
                context.streetwiseActorName = streetwiseActor.name;
            }
        }

        context.SHIPYARD_SELECT = {
            "": game.i18n.localize("MGT2.WorldSheet.Facility.none"),
            "smallcraft": game.i18n.localize("MGT2.WorldSheet.Facility.smallcraft"),
            "spacecraft": game.i18n.localize("MGT2.WorldSheet.Facility.spacecraft"),
            "capital": game.i18n.localize("MGT2.WorldSheet.Facility.capital")
        }
        if (context.world.extra.repair === "repair") {
            // This was using the wrong value.
            if (context.actor.permission >= 3) {
                context.world.extra.repair = "full";
            }
        }
        context.REPAIR_SELECT = {
            "": game.i18n.localize("MGT2.WorldSheet.Facility.none"),
            "limited": game.i18n.localize("MGT2.WorldSheet.Facility.limited"),
            "full": game.i18n.localize("MGT2.WorldSheet.Facility.full")
        }
        context.FUEL_SELECT = {
            "": game.i18n.localize("MGT2.WorldSheet.Facility.none"),
            "unrefined": game.i18n.localize("MGT2.WorldSheet.Facility.unrefined"),
            "refined": game.i18n.localize("MGT2.WorldSheet.Facility.refined")
        }
        context.BASES_SELECT = {
            "": ""
        }
        for (let b of [ "N", "S", "M", "C", "D", "W"]) {
            if (context.world.uwp.bases.indexOf(b) === -1) {
                context.BASES_SELECT[b] = game.i18n.localize("MGT2.WorldSheet.Bases." + b);
            }
        }
        if (Object.keys(context.BASES_SELECT).length === 1) {
            context.BASES_SELECT = null;
        }
        context.CODES_SELECT = {
            "": ""
        }
        for (let code in CONFIG.MGT2.TRADE.codes) {
            if (this.actor.system.world.uwp.codes.indexOf(code) === -1) {
                //context.CODES_SELECT[code] = `${game.i18n.localize("MGT2.Trade." + code)} (${code})`;
                context.CODES_SELECT[code] = code;
            }
        }

        return context;
    }

    _onFuelDragStart(event, options) {
        console.log("onFuelDragStart");
        console.log(options);
        let dragData = {
            "type": "Fuel",
            "worldName": options.worldName,
            "fuel": options.fuel,
            "cost": options.cost
        }
        event.dataTransfer.setData("text/plain", JSON.stringify(dragData));
    }

    activateListeners(html) {
        super.activateListeners(html);

        // Define trade drag listener here, because all players should be able to do it.
        let handler = ev => this._onDragStart(ev);
        html.find('.trade-item').each((i, li) => {
            li.setAttribute("draggable", true);
            li.addEventListener("dragstart", handler, false);
        });
        html.find('.freight').each((i, li) => {
            li.setAttribute("draggable", true);
            li.addEventListener("dragstart", handler, false);
        });
        html.find('.fuelPurchase').each((i, div) => {
            div.setAttribute('draggable', true);
            let options = {
                worldName: this.actor.name,
                fuel: div.getAttribute("data-fuel-type"),
                cost: div.getAttribute("data-fuel-cost")
            }
            let fuelHandler = ev => this._onFuelDragStart(ev, options);
            div.addEventListener("dragstart", fuelHandler, false);
        })

        html.find('.freight-clear').click(ev => {
            const e = $(ev.currentTarget).parents(".destination-title");
            clearFreight(this.actor, e.data("destinationId"));
        });
        html.find('.createFreight').click(ev => {
            createFreight(this.actor, 1, 1000);
        });
        html.find('.generateWorld').click(ev => {
            createWorld(this.actor);
        });
        html.find('.generateSpeculative').click(ev => {
            createSpeculativeGoods(this.actor);
        });
        html.find('.base-remove').click(ev => {
            // Remove base
            const e = $(ev.currentTarget).parents(".world-pill");
            const id = e.data("baseId");
            let re = new RegExp(` ?${id},?`, "g");
            let b = this.actor.system.world.uwp.bases.replaceAll(re, "").replaceAll(/,$/g, "").trim();
            this.actor.update({"system.world.uwp.bases": b});
        });
        html.find('.base-add').click(ev => {
            // Add base
            const value = $(ev.currentTarget).val();
            if (MGT2.WORLD.bases[value]) {
                if (this.actor.system.world.uwp.bases) {
                    this.actor.system.world.uwp.bases += ", " + value;
                } else {
                    this.actor.system.world.uwp.bases = value;
                }
                this.actor.update({"system.world.uwp.bases": this.actor.system.world.uwp.bases});
            }
        });
        html.find('.code-remove').click(ev => {
            // Remove base
            const e = $(ev.currentTarget).parents(".world-pill");
            const id = e.data("codeId");
            let re = new RegExp(` ?${id},?`, "g");
            let b = this.actor.system.world.uwp.codes.replaceAll(re, "").replaceAll(/,$/g, "").trim();
            this.actor.update({"system.world.uwp.codes": b});
        });
        html.find('.code-add').click(ev => {
            // Add base
            const value = $(ev.currentTarget).val();
            if (CONFIG.MGT2.TRADE.codes[value]) {
                if (this.actor.system.world.uwp.codes) {
                    this.actor.system.world.uwp.codes += ", " + value;
                } else {
                    this.actor.system.world.uwp.codes = value;
                }
                this.actor.update({"system.world.uwp.codes": this.actor.system.world.uwp.codes});
            }
        });
        html.find('.unlock-trade-codes').click(ev => {
           this.actor.update({"system.world.extra.autoCodes": false});
        });
        html.find('.lock-trade-codes').click(ev => {
            this.actor.update({"system.world.extra.autoCodes": true});
        });
        html.find('.faction-add').click(ev => {
           // Add faction
            createFaction(this.actor);
        });
        html.find('.patron-add').click(ev => {
            // Add Patron
            this._createPatron();
        });
        html.find('.planet-add').click(ev => {
            // Add Patron
            this._createPlanet();
        });
        html.find('.star-add').click(ev => {
            // Add Patron
            this._createStar();
        });
    }

    async _createPatron() {
        let itemData = {
            name: "Patron",
            type: "worlddata",
            system: {
                world: {
                    datatype: "patron",
                    hidden: true,
                    species: "Human",
                    profession: "Patron"
                }
            }
        };
        Item.create(itemData, { parent: this.actor });
    }

    async _createPlanet() {
        let itemData = {
            name: "Planet",
            type: "worlddata",
            system: {
                world: {
                    datatype: "planet",
                    planetType: "largeGas"
                }
            }
        };
        Item.create(itemData, { parent: this.actor });
    }

    async _createStar() {
        let itemData = {
            name: "Star",
            type: "worlddata",
            system: {
                world: {
                    datatype: "star",
                    spectralType: "G2",
                    luminosityClass: "V"
                }
            }
        };
        Item.create(itemData, { parent: this.actor });
    }

    async _onDrop(event) {
        console.log("Drop on World Sheet");
        console.log(event);

        let data;
        try {
            data = JSON.parse(event.dataTransfer.getData('text/plain'));
        } catch (err) {
            console.log("Could not parse data");
            return false;
        }
        switch (data.type) {
            case "Item":
                return this._onDropItem(event, data);
            case "Actor":
                return this._onDropActor(event, data);
        }
        return true;
    }

    async _onDropItem(event, data) {
        // Do thing.
        super._onDropItem(event, data);
        console.log("On drop item");
        let droppedItem = await fromUuid(data.uuid);
        if (!droppedItem) {
            return;
        }

        if (["cargo"].includes(droppedItem.type)) {
            console.log("Dropping cargo on world");

            return true;
        }

        return;
    }

    async _disembark(passenger) {
        let shipActor = await fromUuid(passenger.system.meta.spacecraftId);
        if (!shipActor) {
            ui.notifications.error("Unable to find spacecraft this actor is on");
            return;
        }
        let list = [];
        let idList = [];
        for (let p in shipActor.system.crewed.passengers) {
            let data = shipActor.system.crewed.passengers[p];
            if (data.destinationId === this.actor.uuid) {
                list.push(await fromUuid("Actor."+p));
                idList.push(p);
            }
        }
        if (list.length > 0) {
            let contentData = {
                destinationName: this.actor.name,
                passengerName: passenger.name,
                passengerList: list
            }
            const content = await renderTemplate("systems/mgt2e/templates/dialogs/disembark-passengers.html", contentData);

            const disembark = await foundry.applications.api.DialogV2.confirm({
                window: {
                    title: "Disembark Passengers?"
                },
                content,
                modal: true
            });
            // This needs to be done as GM.
            if (disembark) {
                const data = {
                    type: "tradeDisembarkPassenger",
                    shipActorId: shipActor.uuid,
                    worldActorId: this.actor.uuid,
                    passengerList: idList
                }
                if (this.actor.permission > 2) {
                    await tradeDisembarkPassengerHandler(data);
                } else {
                    game.socket.emit("system.mgt2e", data);
                }
            }
        }
    }

    async _onDropActor(event, data) {
        let droppedActor = await fromUuid(data.uuid);
        if (!droppedActor) {
            return;
        }
        console.log("_onDropActor:");
        if (droppedActor.type === "npc" && droppedActor.system.meta) {
            if (droppedActor.system.meta.destinationId === this.actor.uuid) {
                this._disembark(droppedActor);
            } else {
                ui.notifications.warn(`${droppedActor.name} doesn't want to disembark here`);
            }
            return;
        }

        if (["npc", "traveller"].includes(droppedActor.type)) {
            let data = {
                type: "worldDropBroker",
                brokerActorId: droppedActor.uuid,
                worldActorId: this.actor.uuid,
            }
            if (event.target.closest(".brokerDropZone")) {
                data.skill = "broker";
                data.skillScore = parseInt(droppedActor.system.skills["broker"].value);
            } else if (event.target.closest(".streetwiseDropZone")) {
                data.skill = "streetwise";
                data.skillScore = parseInt(droppedActor.system.skills["streetwise"].value);
            }
            if (this.actor.permission > 2) {
                await worldDropBrokerHandler(data);
            } else {
                game.socket.emit("system.mgt2e", data);
            }
            return;
        }

        if (droppedActor.type === "world") {
            // Need to calculate trade.
            if (this.actor.permission < 3) {
                ui.notifications.error(`You do not have permission to calculate trade for ${this.actor.name}`);
                return;
            }
            calculateFreightLots(this.actor, droppedActor, 0);
            return;
        }

        // Do nothing.
        return true;
    }

    // Make this world a star system. A star system is only defined on the main world.
    async _createStarSystem() {
        if (this.actor.system.starSystem) {
            // Already exists, nothing to do.
            return;
        }

        let starSystem = {
            "name": this.actor.name
        }
    }
}

